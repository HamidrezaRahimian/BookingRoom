package main;

import lambdasstreams.DataAnalytics;

public class Application {
    public static void main(String... args) {
        DataAnalytics dataAnalytics = new DataAnalytics();
        dataAnalytics.test01();
        dataAnalytics.test02();
        dataAnalytics.test03();
        dataAnalytics.test04();
        dataAnalytics.test05();
        dataAnalytics.test06();
    }
}